package com.example.mybluetooth.ListviewAdapter_file;

public class ListViewAdapterData {
    private String vibration;

    public void setVibration(String name){this.vibration = name;}

    public String getVibration(){return this.vibration;}
}
